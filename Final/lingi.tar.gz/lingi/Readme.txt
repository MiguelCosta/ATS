
Conteúdo:
Gramatica		Pasta com toda a gramatica, Tree Grammars e classes auxiliares.
Relatorio		Pasta com o relatorio desenvolvido
WebSite			Site desenvolvido em PHP para apresentar o trabalho


Trabalho desenvolvido por:
- Milton Nunes - milton.nunes52@gmail.com 
- Miguel Costa - miguelpintodacosta@gmail.com


Mestrado em Engenharia Informática
Análise e Concepção de Software
UCE30: Análise e transformação de Software
2012/2013
