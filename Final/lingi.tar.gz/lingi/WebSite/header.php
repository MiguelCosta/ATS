<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>ATS</title>
        <link rel="stylesheet" href="css/style.css" type="text/css" />
        <!--[if IE 7]>
        <link rel="stylesheet" href="css/ie7.css" type="text/css" />
        <![endif]-->
    </head>
    <body>
        <div class="page">
            <div class="header">
                <a href="index.php" id="logo"><h1>ATS</h1></a>
                <ul>
                    <li>
                        <a href="criar.php">Inserir código</a>
                    </li>
                    <li>
                        <a href="cfg.php">CFG</a>
                    </li>
                    <li>
                        <a href="pdg.php">PDG</a>
                    </li>
                    <li>
                        <a href="ssa.php">SSA</a>
                    </li>
                    <li>
                        <a href="sdg.php">SDG</a>
                    </li>
                    <li>
                        <a href="msp.php">MSP</a>
                    </li>
                    <li>
                        <a href="metricas.php">ME</a>
                    </li>
                </ul>
                </ul>
            </div>
            <div class="body">