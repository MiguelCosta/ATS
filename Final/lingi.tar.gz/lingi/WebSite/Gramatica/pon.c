void imprime(string nome)
{
	int a;
	int b;
	string c;

	print(a);
	while(1){
		b=a;
		if(b){
			a=2;
		}
		else {
			a = b + a;
		}
		a=a;
	}
	print(b);
	while(1){
		while(2){
			a=a;
		}
		print("Teste");
	}
	if (a) {
		b= b+1;
		while(1){
			scan(c);
		}
		c = "ola";
	}
	else {
		while(3){
			scan(c);
		}
		print(c);
	}

}
