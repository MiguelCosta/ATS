void coiso() {
	int a;

	a = 5;
c = 55;
	if(b) {
		d = a;
		b = c+1;
	}
}
