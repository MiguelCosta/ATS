void imprime(string nome)
{
	int a;
	int b;
	int c;
	int d;

	a = 55;
	b = 55;
	c = 55;
	a = b -a ;
	if (b) {
		c = a;
		c = c + 30;
		a = 20;
	}
	else {
		c=c+1;
		c = 10 -c;
		b = 10;
	}
	d = a +b+ c;

}
