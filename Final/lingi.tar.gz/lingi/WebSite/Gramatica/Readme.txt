
> javac Run.java
> java Run ../input.c
