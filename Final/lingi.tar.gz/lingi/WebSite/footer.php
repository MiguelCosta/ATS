
</div>
<div class="footer">
    <ul>
        <li>
            <a href="index.php">Ínicio</a>
        </li>
        <li>
            <a href="criar.php">Inserir código</a>
        </li>
        <li>
            <a href="cfg.php">CFG</a>
        </li>
        <li>
            <a href="pdg.php">PDG</a>
        </li>
        <li>
            <a href="ssa.php">SSA</a>
        </li>
        <li>
            <a href="sdg.php">SDG</a>
        </li>
        <li>
            <a href="msp.php">MSP</a>
        </li>
        <li>
            <a href="metricas.php">ME</a>
        </li>
    </ul>
    &#169; Copyright &#169; 2013
    <div class="connect">
        Milton Nunes e Miguel Costa
    </div>
</p>
</div>
</div>
</body>
</html>
