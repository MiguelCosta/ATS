int main (int args){
	int i = 10;
	i = i+1;
	int a;
	a = 20;
	
	while(i<a){
		i = i+1;
	}
	
	for(i+10; i < a; i=i+1){
		a = a-1;
		i = i-1;
	}
	return a;
}
